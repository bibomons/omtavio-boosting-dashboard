# Omtavio Cloud Dashboard — starter

This is a Cloudflare Pages starter for the Omtavio Boost Manager web dashboard.

## Architecture
- `public/`: static website hosted on Cloudflare Pages.
- `functions/api/[[path]].js`: Pages Function that authenticates the workspace and proxies API requests to the existing Node/Express backend.
- The backend and its JSON data remain on the Pterodactyl server.
- The browser never receives the backend API key.

## Before deployment
1. Deploy this folder as a Cloudflare Pages project. Build command: leave blank. Build output directory: `public`.
2. Configure these **Pages project secrets/environment variables** (Production and Preview as appropriate):
   - `APP_PASSWORD`: a new, strong workspace login password.
   - `SESSION_SECRET`: a long random secret (at least 32 random bytes).
   - `BACKEND_URL`: the HTTPS origin of the backend reachable through Cloudflare Tunnel, with no `/api` suffix. Example shape: `https://api.your-domain.example`
   - `BACKEND_API_KEY`: the same API key already configured on the backend. Never put it in frontend files or share it in chat.
3. Create a Cloudflare Tunnel route for the backend hostname to the Pterodactyl backend service on port `30005`. Keep the backend hostname private behind the tunnel where possible; do not publish the raw VPS port.
4. Test `/api/health` through the Pages Function after deployment.

## Important current limitations
- This starter reads Overview, Accounts, Plans, and Activity from the existing API.
- The planner form is intentionally not wired to create a plan yet because the current API requires capacity data and the current Accounts API does not store verified capacity. The UI must not pretend user-entered capacity is verified.
- Plan approval only records approval in the existing backend; it does not perform any Discord Boost operation.
- This is a starter, not a production security review. Add rate limiting, password rotation, account recovery, and stronger user/session management before exposing it broadly.
- Do not use Discord user tokens, scrape browser sessions, or automate Boost actions.
