const encoder = new TextEncoder();
const COOKIE = "omtavio_session";
const SESSION_SECONDS = 60 * 60 * 8;

function b64url(bytes) {
  let binary = ""; bytes.forEach(b => binary += String.fromCharCode(b));
  return btoa(binary).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
}
function fromB64url(value) {
  const padded=value.replace(/-/g,"+").replace(/_/g,"/")+"===".slice((value.length+3)%4);
  const binary=atob(padded); return Uint8Array.from(binary,c=>c.charCodeAt(0));
}
async function sign(payload, secret) {
  const key=await crypto.subtle.importKey("raw",encoder.encode(secret),{name:"HMAC",hash:"SHA-256"},false,["sign"]);
  return new Uint8Array(await crypto.subtle.sign("HMAC",key,encoder.encode(payload)));
}
async function validSession(request, env) {
  const cookie=request.headers.get("Cookie")||"";
  const match=cookie.split(";").map(x=>x.trim()).find(x=>x.startsWith(COOKIE+"="));
  if(!match) return false;
  const token=match.slice(COOKIE.length+1).split(".");
  if(token.length!==2) return false;
  try {
    const payload=token[0], supplied=fromB64url(token[1]), expected=await sign(payload,env.SESSION_SECRET);
    if(supplied.length!==expected.length) return false;
    let diff=0; for(let i=0;i<supplied.length;i++) diff|=supplied[i]^expected[i];
    if(diff!==0) return false;
    const data=JSON.parse(new TextDecoder().decode(fromB64url(payload)));
    return data.exp>Date.now();
  } catch { return false; }
}
function cookie(value,maxAge){return `${COOKIE}=${value}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${maxAge}`;}
function json(data,status=200,headers={}){return new Response(JSON.stringify(data),{status,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store",...headers}});}
export async function onRequest(context) {
  const {request,env}=context; const url=new URL(request.url);
  const path=url.pathname.replace(/^\/api\/?/,"");
  if(!env.APP_PASSWORD||!env.SESSION_SECRET||!env.BACKEND_URL||!env.BACKEND_API_KEY)
    return json({success:false,error:"Cloudflare environment secrets are not configured."},503);

  if(path==="login" && request.method==="POST"){
    let body={};try{body=await request.json();}catch{return json({success:false,error:"Invalid JSON"},400);}
    if(typeof body.password!=="string" || body.password!==env.APP_PASSWORD)
      return json({success:false,error:"Incorrect workspace password"},401);
    const payload=b64url(encoder.encode(JSON.stringify({exp:Date.now()+SESSION_SECONDS*1000})));
    const signature=b64url(await sign(payload,env.SESSION_SECRET));
    return json({success:true},200,{"Set-Cookie":cookie(`${payload}.${signature}`,SESSION_SECONDS)});
  }
  if(path==="logout" && request.method==="POST")
    return json({success:true},200,{"Set-Cookie":cookie("",0)});
  if(path==="me" && request.method==="GET")
    return await validSession(request,env)?json({success:true,authenticated:true}):json({success:false,error:"Unauthorized"},401);

  if(!await validSession(request,env)) return json({success:false,error:"Unauthorized"},401);
  const backendBase=env.BACKEND_URL.replace(/\/+$/,"");
  const target=new URL(`${backendBase}/api/${path}${url.search}`);
  const headers=new Headers();
  headers.set("x-api-key",env.BACKEND_API_KEY);
  const contentType=request.headers.get("Content-Type");
  if(contentType) headers.set("Content-Type",contentType);
  const init={method:request.method,headers};
  if(!["GET","HEAD"].includes(request.method)) init.body=await request.arrayBuffer();
  try{
    const upstream=await fetch(target.toString(),init);
    return new Response(upstream.body,{status:upstream.status,headers:{
      "Content-Type":upstream.headers.get("Content-Type")||"application/json",
      "Cache-Control":"no-store"
    }});
  }catch{return json({success:false,error:"Could not reach the Omtavio backend."},502);}
}