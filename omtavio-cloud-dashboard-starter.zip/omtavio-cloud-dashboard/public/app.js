const $ = (id) => document.getElementById(id);
const api = async (path, options = {}) => {
  const response = await fetch(`/api/${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const data = await response.json().catch(() => ({}));
  if (response.status === 401) { showLogin(); throw new Error("Session expired. Please sign in again."); }
  if (!response.ok || data.success === false) throw new Error(data.error || `Request failed (${response.status})`);
  return data;
};
function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600)}
function showLogin(){ $("appView").classList.add("hidden"); $("loginView").classList.remove("hidden"); }
function showApp(){ $("loginView").classList.add("hidden"); $("appView").classList.remove("hidden"); loadOverview(); }
$("loginForm").addEventListener("submit", async e=>{
  e.preventDefault(); $("loginError").textContent="";
  try { await api("login",{method:"POST",body:JSON.stringify({password:$("password").value})}); $("password").value=""; showApp(); }
  catch(err){$("loginError").textContent=err.message;}
});
$("logoutBtn").addEventListener("click",async()=>{try{await api("logout",{method:"POST"});}finally{showLogin();}});
document.querySelectorAll(".nav-item").forEach(btn=>btn.addEventListener("click",()=>navigate(btn.dataset.page)));
function navigate(page){
  document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  document.querySelectorAll(".page").forEach(p=>p.classList.add("hidden"));
  $(`page-${page}`).classList.remove("hidden");
  $("pageTitle").textContent=({overview:"Overview",accounts:"Accounts",planner:"Boost Planner",activity:"Activity"})[page];
  $("crumb").textContent=page.toUpperCase();
  if(page==="accounts")loadAccounts(); if(page==="planner")loadPlans(); if(page==="activity")loadActivity();
}
async function loadOverview(){
  try{
    const [health,accounts,plans,activity]=await Promise.all([api("health"),api("accounts"),api("planner/plans"),api("activity?limit=5")]);
    $("connectionText").textContent="Backend online"; $("serviceName").textContent=health.service||"Omtavio API";
    $("healthText").textContent=`Version ${health.version||"—"} · Last checked ${new Date().toLocaleTimeString()}`;
    $("healthBadge").textContent="Operational"; $("statAccounts").textContent=accounts.total??accounts.accounts?.length??0;
    $("statPlans").textContent=plans.total??plans.plans?.length??0; $("statActivity").textContent=activity.total??activity.logs?.length??0;
  }catch(e){$("connectionText").textContent="Backend unavailable";$("healthText").textContent=e.message;$("healthBadge").textContent="Offline";$("healthBadge").style.color="var(--red)";}
}
async function loadAccounts(){
  const box=$("accountsList");box.textContent="Loading…";
  try{const d=await api("accounts");const rows=d.accounts||[];box.innerHTML=rows.length?rows.map(a=>`<div class="data-row"><div><b>${escapeHtml(a.name)}</b><small>${escapeHtml(a.profileLabel||"No profile label")} · Added ${new Date(a.createdAt).toLocaleDateString()}</small></div><span class="tag">${escapeHtml(a.status||"registered")}</span></div>`).join(""):"No accounts registered yet.";}
  catch(e){box.textContent=e.message;}
}
async function loadPlans(){
  const box=$("plansList");box.textContent="Loading…";
  try{const d=await api("planner/plans");const rows=d.plans||[];box.innerHTML=rows.length?rows.map(p=>`<div class="data-row"><div><b>Plan · ${p.target} requested</b><small>${new Date(p.createdAt).toLocaleString()} · ${p.totalAssigned} allocated in preview</small></div><span class="tag">${escapeHtml(p.status)}</span></div>`).join(""):"No plans created yet.";}
  catch(e){box.textContent=e.message;}
}
async function loadActivity(){
  const box=$("activityList");box.textContent="Loading…";
  try{const d=await api("activity?limit=50");const rows=d.logs||[];box.innerHTML=rows.length?rows.map(a=>`<div class="data-row"><div><b>${escapeHtml(a.action)}</b><small>${new Date(a.timestamp).toLocaleString()}</small></div><span class="tag">Logged</span></div>`).join(""):"No activity recorded yet.";}
  catch(e){box.textContent=e.message;}
}
$("refreshBtn").addEventListener("click",loadOverview);$("reloadAccounts").addEventListener("click",loadAccounts);$("reloadPlans").addEventListener("click",loadPlans);$("reloadActivity").addEventListener("click",loadActivity);
$("createPreview").addEventListener("click",async()=>{
  $("plannerMessage").textContent="This first web release only displays existing plans. Account capacity entry will be added after the secure account workflow is finalized.";
  toast("Planner preview form is being connected in the next build.");
});
function escapeHtml(value){return String(value??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
(async()=>{try{await api("me");showApp();}catch{showLogin();}})();
